# UBD CVD risk calculator

### Soft and Tools Requirements

1. [Github Accound](https://github.com/Mohammedarwesh)
2. [GitCLI]
3. [Herokuaccount](https://dashboard.heroku.com/apps)
